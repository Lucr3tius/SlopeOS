import type React from "react"
import type { Metadata } from "next"
import "./globals.css"
import { ThemeProvider } from "../contexts/theme-context"

export const metadata: Metadata = {
  title: "Management Dashboard",
  description: "Management system dashboard",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="bg-neutral-50 dark:bg-black text-neutral-900 dark:text-white font-sans antialiased">
        <ThemeProvider defaultTheme="dark" storageKey="management-ui-theme">
          {children}
        </ThemeProvider>
      </body>
    </html>
  )
}
