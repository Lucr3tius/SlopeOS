"use client"

import type React from "react"

import type { DraggableProps } from "react-draggable"
import Draggable from "react-draggable"

/**
 * Generic draggable wrapper.
 *
 * Wrap any JSX (e.g. a <Card/>) to allow free-form repositioning.
 *
 *  <DraggableCard>
 *    <Card> … </Card>
 *  </DraggableCard>
 */
export default function DraggableCard({
  children,
  ...props
}: {
  children: React.ReactNode
} & Partial<DraggableProps>) {
  return (
    <Draggable handle="[data-draggable-handle]" {...props}>
      <div className="cursor-move select-none">{children}</div>
    </Draggable>
  )
}
